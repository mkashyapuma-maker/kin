import express from "express";
import dotenv from "dotenv";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
import { GoogleGenAI } from "@google/genai";

dotenv.config();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(express.json({ limit: "1mb" }));

const apiKey = process.env.GEMINI_API_KEY;
const keyOk = !!apiKey && !apiKey.startsWith("PASTE_");
if (!keyOk) console.warn("WARNING: GEMINI_API_KEY missing in .env — the app runs, but AI replies will show a setup message.");
const ai = keyOk ? new GoogleGenAI({ apiKey }) : null;
const MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";
const PORT = Number(process.env.PORT) || 3001;

const LANGS = { en: "English", kn: "Kannada (ಕನ್ನಡ)", hi: "Hindi (हिन्दी)" };

const EMERGENCY = /(chest pain|can'?t breathe|cannot breathe|heart attack|stroke|unconscious|bleeding heavily|suicid|kill myself|end my life|want to die|overdose|fell and can'?t|छाती में दर्द|सांस नहीं|आत्महत्या|मरना चाहत|ಎದೆ ನೋವು|ಉಸಿರಾಡಲು|ಆತ್ಮಹತ್ಯೆ|ಸಾಯಬೇಕು)/i;
const EMERGENCY_REPLY = {
  en: "I'm really concerned about what you said. Please call your local emergency number right now (India: 112, ambulance 108), or ask someone nearby to help you. If it's about feeling hopeless, please call or tell a trusted person now — in India, Tele-MANAS is 14416. I'm not a doctor, but I'm here with you.",
  hi: "आपकी बात से मुझे चिंता हो रही है। कृपया अभी 112 (एम्बुलेंस 108) पर कॉल करें या पास के किसी व्यक्ति को बुलाएँ। अगर मन बहुत भारी है तो किसी भरोसेमंद व्यक्ति को बताएँ या Tele-MANAS 14416 पर कॉल करें। मैं डॉक्टर नहीं हूँ, पर आपके साथ हूँ।",
  kn: "ನೀವು ಹೇಳಿದ್ದನ್ನು ಕೇಳಿ ನನಗೆ ಚಿಂತೆಯಾಗಿದೆ. ದಯವಿಟ್ಟು ಈಗಲೇ 112 (ಆಂಬ್ಯುಲೆನ್ಸ್ 108) ಗೆ ಕರೆ ಮಾಡಿ ಅಥವಾ ಹತ್ತಿರದವರನ್ನು ಕರೆಯಿರಿ. ಮನಸ್ಸು ತುಂಬಾ ಭಾರವಾಗಿದ್ದರೆ ನಂಬಿಕಸ್ಥರಿಗೆ ಹೇಳಿ ಅಥವಾ Tele-MANAS 14416 ಗೆ ಕರೆ ಮಾಡಿ. ನಾನು ವೈದ್ಯನಲ್ಲ, ಆದರೆ ನಿಮ್ಮ ಜೊತೆ ಇದ್ದೇನೆ."
};

function systemPrompt({ mode, lang, name, memory, items }) {
  const p = [
    `You are Kin, a warm, patient voice companion for an older adult${name ? " named " + name : ""}, or anyone feeling lonely.`,
    `Preferred language: ${LANGS[lang] || "English"}. Reply in the language the person actually uses; mixed Kannada/Hindi/English is fine. Use the native script for Kannada/Hindi unless they write in Roman letters.`,
    "Use short, clear, gentle sentences (2-4 sentences). Avoid markdown, lists, and emojis because replies are read aloud.",
    "Never claim you called anyone, set a reminder, or controlled a device. Reminders are only managed by the person in the Daily Manager tab.",
    "For emergencies or serious symptoms, urge contacting local emergency services (India 112/108) or a trusted person; never diagnose or give medicine doses. Do not pretend to be a doctor.",
    "Only items the person marked 'shareable' may ever be shared with family or caregivers; treat 'private' items as confidential and ask before treating personal details as shareable."
  ];
  if (mode === "daily") p.push("MODE: Daily Manager helper. Help them think through their day, gently remind them what is on their list, and suggest they use the Add buttons to save new items. Keep it practical.");
  else p.push("MODE: Friend. Be empathetic, listen first, encourage, ask one gentle follow-up question, and share small cheerful thoughts. Don't lecture.");
  if (memory?.length) p.push("Things the person agreed to let you remember: " + memory.slice(0, 20).join("; ") + ".");
  if (items?.length) p.push("Their current list (for context): " + items.slice(0, 25).join("; ") + ".");
  return p.join(" ");
}

app.get("/api/health", (_req, res) => res.json({ ok: true, model: MODEL, keyConfigured: keyOk }));

app.post("/api/chat", async (req, res) => {
  try {
    const { message, history, mode, lang, name, memory, items } = req.body || {};
    if (typeof message !== "string" || !message.trim()) return res.status(400).json({ error: "Please enter a message." });
    const text = message.trim().slice(0, 2000);
    const L = LANGS[lang] ? lang : "en";
    if (EMERGENCY.test(text)) return res.json({ reply: EMERGENCY_REPLY[L], emergency: true });
    if (!ai) return res.status(503).json({ error: "The AI key isn't set up yet. Add GEMINI_API_KEY to the .env file and restart the server." });

    const contents = [];
    for (const h of Array.isArray(history) ? history.slice(-10) : []) {
      if (h && typeof h.text === "string" && (h.role === "user" || h.role === "model"))
        contents.push({ role: h.role, parts: [{ text: h.text.slice(0, 1500) }] });
    }
    contents.push({ role: "user", parts: [{ text }] });
    const result = await ai.models.generateContent({
      model: MODEL,
      contents,
      config: {
        systemInstruction: systemPrompt({
          mode, lang: L, name: String(name || "").slice(0, 40),
          memory: Array.isArray(memory) ? memory.map(String) : [],
          items: Array.isArray(items) ? items.map(String) : []
        }),
        temperature: 0.7,
        maxOutputTokens: 400
      }
    });
    res.json({ reply: result.text || "I'm here with you. Could you say a little more?" });
  } catch (err) {
    console.error("Gemini request failed:", err?.message || err);
    const quota = /429|quota|RESOURCE_EXHAUSTED/i.test(String(err?.message));
    const badKey = /API key|API_KEY_INVALID|401|403/i.test(String(err?.message));
    res.status(500).json({
      error: quota ? "Kin has reached the free AI limit for now. Please wait a minute and try again."
        : badKey ? "The Gemini API key looks invalid. Check GEMINI_API_KEY in .env."
        : "Kin couldn't get an AI reply. Check the server terminal."
    });
  }
});

// Serve the production build when present. This app is also a single-file HTML
// frontend, so it can run on hosted platforms even before a build directory exists.
const dist = path.join(__dirname, "dist");
const webRoot = fs.existsSync(path.join(dist, "index.html")) ? dist : __dirname;
app.use(express.static(webRoot));
app.get(/^\/(?!api(?:\/|$)).*/, (_req, res) => {
  res.sendFile(path.join(webRoot, "index.html"));
});

app.listen(PORT, "0.0.0.0", () => console.log(`Kin server running on port ${PORT} (model: ${MODEL}, key: ${keyOk ? "set" : "MISSING"})`));
