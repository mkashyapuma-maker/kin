@echo off
setlocal
cd /d "%~dp0"
title Kin Voice Companion
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed or not on PATH.
  echo Install the LTS version from https://nodejs.org, then double-click START_KIN.bat again.
  pause
  exit /b 1
)
if not exist ".env" (
  copy ".env.example" ".env" >nul
  echo.
  echo First setup: your private .env file has been created.
  echo Notepad will open. Paste your Gemini API key after GEMINI_API_KEY=, save, and close Notepad.
  echo Keep this key private. Do not send it to anyone.
  notepad .env
  echo.
  echo Now double-click START_KIN.bat again to launch Kin.
  pause
  exit /b 0
)
if not exist "node_modules" (
  echo Installing Kin dependencies. This can take a few minutes...
  call npm.cmd install
  if errorlevel 1 (
    echo Install failed. Check your internet connection and try again.
    pause
    exit /b 1
  )
)
echo Starting Kin (server + website). Keep this window open. Browser opens automatically.
call npm.cmd run dev
pause
