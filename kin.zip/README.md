# Kin — a voice-first companion for elders and anyone lonely

Friend mode (empathetic chat + voice), Daily Manager (medicines, birthdays, tasks), English / Kannada / Hindi, consent-based memory, Private/Shareable labels, emergency guidance.

## Setup (needs Node.js 18+)
```
npm install
cp .env.example .env     # Windows: copy .env.example .env
# edit .env: GEMINI_API_KEY=your_key   (free key: https://aistudio.google.com/apikey)
npm run dev              # starts API (port 3001) + website (http://127.0.0.1:5173)
```
Windows: double-click `START_KIN.bat`. Use **Google Chrome or Edge** for the microphone.

## Environment variables
| Name | Purpose |
|---|---|
| `GEMINI_API_KEY` | required for AI replies (stays on the server, never in frontend code) |
| `GEMINI_MODEL` | optional, default `gemini-2.5-flash` |
| `PORT` | optional, default 3001 |

## The connection error — what was fixed
The Vite proxy pointed to `localhost`, which can resolve to IPv6 (`::1`) while the server was on IPv4, and the server exited immediately if the key was missing. Now the proxy uses `127.0.0.1`, the server stays up without a key (the UI shows a clear setup banner), and `npm run dev` starts both processes together.

## 2-minute demo
1. Open the app → walkthrough appears. 2. Privacy tab → switch memory on, add "Likes evening tea". 3. Daily tab → **Load sample data**, mark one done, delete one. 4. Friend tab → tap mic (or a suggestion chip): "I feel lonely today". 5. Switch to हिन्दी / ಕನ್ನಡ and speak. 6. Type "I have chest pain" → emergency banner + 112 guidance.

## Tested
Automated browser run (headless Chromium, mobile size): walkthrough, add/complete/delete, persistence after reload, memory notes, language switch, emergency banner, API-down and missing-key messages — no console errors. Server emergency path verified with curl.
**Not tested here:** live Gemini replies (needs your key), real microphone/speech recognition, and spoken output — please test those on your machine in Chrome.

## Known limitations
- Voice recognition/speech output come from the browser; Kannada/Hindi accuracy and voice availability vary by device. Mixed-language speech is best-effort via Gemini text, not guaranteed.
- Reminders only show while Kin is open — no background notifications.
- Data lives in browser localStorage: **not encrypted**, not synced. Memory is not "secure persistent memory".
- "Shareable" is only a label; no family/caregiver sharing exists yet.
- Emergency detection is a keyword list, not a medical system. No Alexa integration. Kin cannot call anyone.

## Deploy on Replit
1. Upload this project folder/ZIP to a Replit app.
2. Add `GEMINI_API_KEY` in **Replit Secrets** (do not paste it into chat or frontend code).
3. Run `npm install`, then `npm start`. For deployment use build command `npm install` and run command `npm start`.
4. Check `/api/health` on the published URL. It should return `ok: true` and `keyConfigured: true`.

The server listens on the hosting platform's `PORT`, binds to `0.0.0.0`, and serves the homepage even when a `dist/` folder has not been built. HTTPS is needed for browser microphone access.

## Deploy on other Node hosts
Build: `npm install && npm run build`. Start: `npm start`. Set `GEMINI_API_KEY` in the host's environment settings.
