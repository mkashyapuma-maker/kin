// Starts the AI server and the website together: npm run dev
import { spawn } from "node:child_process";
const run = (cmd, args) => spawn(cmd, args, { stdio: "inherit", shell: process.platform === "win32" });
const s = run("node", ["server.js"]);
const v = run("npx", ["vite", "--open"]);
const stop = () => { s.kill(); v.kill(); process.exit(); };
process.on("SIGINT", stop); process.on("SIGTERM", stop);
