# Kin — Submission

**Problem.** Millions of older adults live alone. Loneliness harms health, and forgetting medicines or birthdays adds risk and isolation. Most apps are small-text, English-only and typing-heavy.

**Solution.** Kin is a warm voice-first companion. *Friend mode* listens, encourages and chats in English, Kannada or Hindi. *Daily Manager* keeps medicine, birthday and task reminders with large, simple controls. The person decides what Kin remembers.

**Innovation.** Companionship and daily routine in one calm interface; voice in/out for Indian languages; consent-first memory with Private/Shareable labels on every item; built-in emergency guidance (112/108, Tele-MANAS) that bypasses the AI; runs on free tiers with no app install.

**Impact.** Reduces isolation, supports medicine routines, and offers a future path for families to see only what elders approve. Accessible to low-tech users and nearly free to deploy.

**Tech stack.** Vanilla JS + Vite frontend, Node/Express backend, Google Gemini API (`@google/genai`), browser Web Speech API (recognition + synthesis), localStorage.

**60-second demo script.**
- 0:00 "Meet Kin, a companion for people who feel alone." Skip the walkthrough.
- 0:10 Friend tab: tap mic, say "I feel lonely today." Kin answers in text and voice.
- 0:25 Switch to हिन्दी, say a short sentence; Kin replies in Hindi.
- 0:35 Daily tab: load sample data, mark the BP tablet done, add "Call Meena" as Shareable.
- 0:47 Privacy tab: memory is off by default; switch on, add a note, show delete-all.
- 0:53 Type "I have chest pain" → emergency banner, 112 guidance.
- 0:58 "Kin: a little company, whenever you need it."

**Honest limits:** browser-based speech (accuracy varies), no background notifications, local unencrypted storage, no caregiver sharing yet.
