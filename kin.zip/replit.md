# Kin on Replit

## Run and deploy
- Run command: `npm start`
- Build command: `npm install`
- Add `GEMINI_API_KEY` in Replit Secrets (Tools / Secrets or the Secrets panel). Never put the key in frontend code or commit it.
- The Express server serves `index.html` directly when there is no production build, and serves `dist/` if it exists. It listens on `process.env.PORT` and binds to `0.0.0.0`.
- Health check: `/api/health`

The AI chat requires a valid Gemini API key. The reminder list is stored locally in the browser. Voice recognition availability depends on the browser; use HTTPS and Chrome/Edge for microphone access.
